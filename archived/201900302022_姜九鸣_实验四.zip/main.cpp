#include <bits/stdc++.h>
#include <GL/glut.h>
using namespace std;

const int polygon_num=2;
const int winwidth=600,winheight=600;
const int centX=winwidth*0.5,centY=winheight*0.5;

const double bSFDF=2.0;//bSplineFactorDistanceFactor,即参数均匀分布的B样条曲线，对于任意i，其i到i+1的距离=1/bSFDF。
const double renderRate=0.005;//渲染间隔。即每个渲染点之间的距离。

int curType=0;//0:bezier 1:bspline
int curOrder=3;
bool isCreatingNewSpline=true;
bool isHandsTool=false;
bool isEraserTool=false;
bool displayPolynomial=false;

int subMenuOrder=0;
int subMenuTools=0;

struct Point{
    double x,y;
    Point(double x_,double y_):x(x_),y(y_){}
};

class Spline{
	public:
		vector<Point> pv;
		int type=0;
		int order=3;
};
vector<Spline> ss;

bool hits(const Point& mouse,const Point& target){
	//点交互判定范围
	return (abs(target.x-mouse.x)<=1&&abs(target.y-mouse.y<=1));
}

double tao(const int& r,const double & t,const int& i,const int& k,const vector<double>& T){
	return (t-T[i])/(T[i+k-r]-T[i]);
}

double deBoor(const int& r,const double & t,const int& i,const int& k,bool isX,const vector<Point>& pv,const vector<double>& T){
	if(r==0)return isX ? pv.at(i).x : pv.at(i).y;
	return (1-tao(r,t,i,k,T))* deBoor(r-1,t,i-1,k,isX,pv,T)+tao(r,t,i,k,T)*deBoor(r-1,t,i,k,isX,pv,T);
}

double bezier(const int& n,const double& t,const int& k,const bool& isX,const vector<Point>& pv){
	if(k==0)return isX ? pv[n].x : pv[n].y;
	return (1-t) * bezier(n,t,k-1,isX,pv) + t* bezier(n+1,t,k-1,isX,pv);
}

vector<Point> calBezier(const vector<Point>& pv,const int& k){
	vector<Point> res;
	if(pv.size()<k+1)return res;
	for(double t=0.0;t<=1.0;t+=renderRate){
		res.emplace_back(bezier(0,t,k,true,pv),bezier(0,t,k,false,pv));
	}
	return res;
}

vector<Point> callDeBoor(const vector<Point>& pv,const vector<double>& T,const int& k){
	vector<Point> res;
	for(int j=k-1;j<pv.size();j++)
		for(double t=T[j];t<T[j+1];t+=renderRate){
			res.emplace_back(deBoor(k-1,t,j,k,true,pv,T),deBoor(k-1,t,j,k,false,pv,T));
		}
	return res;
}

/*
void drawBezier(const vector<Point>& pv,int order){
	//开始绘制
	glPointSize(4);
	glBegin(GL_POINTS);
	glColor3f(1,0,0);
	//屏幕中心画点
	// glVertex2i(centX,centY);
	vector<Point> vpp = calBezier(pv,order);
	for(auto ite=pv.begin();ite!=pv.end();ite++)glVertex2i(ite->x,+ite->y);
	glColor3f(0,1,0);
	for(auto ite=vpp.begin();ite!=vpp.end();ite++)glVertex2i(ite->x,+ite->y);
	glEnd();
	glFlush();
}
*/

void render(const vector<Point>& pv,int order,int type){
	//渲染一切元素
	//计算出各平均分布的支撑区间的长度
	vector<double> T;
	for(int i=0;i<=pv.size()+1;i++) T.push_back(i/bSFDF);
	//开始绘制
	glPointSize(4);
	glBegin(GL_POINTS);
	//屏幕中心画点
	// glVertex2i(centX,centY);
	//计算曲线
	vector<Point> vpp = type==1? callDeBoor(pv,T,order) : calBezier(pv,order);
	
	//画样条曲线
	glColor3f(83/255.0,71/255.0,65/255.0);
	for(auto ite=vpp.begin();ite!=vpp.end();ite++)glVertex2i(ite->x,+ite->y);
	glEnd();

	//画控制点
	glPointSize(6);
	glBegin(GL_POINTS);
	glColor3f(255/255.0,179/255.0,0/255.0);
	for(auto ite=pv.begin();ite!=pv.end();ite++)glVertex2i(ite->x,+ite->y);
	glEnd();

	//画控制多边形
	if(displayPolynomial){
		glPointSize(3);
		glBegin(GL_LINE_STRIP);
		glColor3f(255/255.0,179/255.0,0/255.0);
		for(auto ite=pv.begin();ite!=pv.end();ite++)glVertex2i(ite->x,+ite->y);
		glEnd();
	}

	glFlush();
}

void drawSplines(){
	for(auto ite=ss.begin();ite!=ss.end();ite++){
		render(ite->pv,ite->order,ite->type);
	}
}

void refreshGraphics(){
	glClear(GL_COLOR_BUFFER_BIT);
	if(!ss.empty()) 
		drawSplines();
}

void createNewSpline(int x, int y){
	Spline spline;
	spline.pv.push_back(Point((double)x,(double)y));
	spline.type=curType;
	spline.order=curOrder;
	ss.push_back(spline);
}

void myMouse(int button, int state, int mouse_x, int mouse_y)
{
	int x=mouse_x,y=winheight-mouse_y;
	if (state == GLUT_DOWN)
	{
		if (button == GLUT_LEFT_BUTTON)
		{
			if(!isHandsTool&&!isEraserTool){
			
				if(isCreatingNewSpline){
					createNewSpline(x,y);
					isCreatingNewSpline=false;
				}
				else{
					ss.back().pv.emplace_back(x,y);
				}
				refreshGraphics();

			}else if(isEraserTool){

				for(auto ite=ss.begin();ite!=ss.end();ite++){
					for(auto itei=ite->pv.begin();itei!=ite->pv.end();itei++){
						if(hits(Point((double)x,(double)y),*itei)){
							ite->pv.erase(itei);
							refreshGraphics();
						}
					}
				}
			}
		}
	}
}

void myMouseMotion(int mouse_x,int mouse_y){
	int x=mouse_x,y=winheight-mouse_y;
	if(isHandsTool){
		for(auto ite=ss.begin();ite!=ss.end();ite++){
			for(auto itei=ite->pv.begin();itei!=ite->pv.end();itei++){
				if(hits(Point((double)x,(double)y),*itei)){
					itei->x=x;
					itei->y=y;
					refreshGraphics();
				}
			}
		}
	}
}

void clearScreen(){
	ss.clear();
	glClear(GL_COLOR_BUFFER_BIT);
	isCreatingNewSpline=true;
}

void subMenuToolsFunc(int value){
	refreshGraphics();

	switch (value)
	{
		case 1:
			isHandsTool=false;
			isEraserTool=false;
			isCreatingNewSpline=true;
			curType=0;
			break;

		case 2:
			isHandsTool=false;
			isEraserTool=false;
			isCreatingNewSpline=true;
			curType=1;
			break;

		case 3:
			isHandsTool=true;
			isCreatingNewSpline=false;
			isEraserTool=false;
			break;

		case 4:
			clearScreen();
			break;

		case 5:
			isEraserTool=true;
			isHandsTool=false;
			isCreatingNewSpline=false;
			break;
		
		default:
			break;
	}

}

void subMenuOrderFunc(int value){
	refreshGraphics();
	curOrder=value;
	isCreatingNewSpline=true;
	refreshGraphics();
}

void mymenu(int value){
	refreshGraphics();
	
	if (value == 1){
		isCreatingNewSpline=true;
	}

	if (value == 2){
		exit(0);
	}

	if (value == 3){
		displayPolynomial=!displayPolynomial;
		refreshGraphics();
	}

}

void myDisp(){
	glClear(GL_COLOR_BUFFER_BIT);
	refreshGraphics();
	glFlush();
}

void initMenu(){
	subMenuTools = glutCreateMenu(subMenuToolsFunc);
	glutAddMenuEntry("Bezier Tool",1);
	glutAddMenuEntry("B-Spline Tool",2);
	glutAddMenuEntry("Hands Tool",3);
	glutAddMenuEntry("Eraser Tool",5);
	glutAddMenuEntry("Delete All Splines",4);

	subMenuOrder = glutCreateMenu(subMenuOrderFunc);
	glutAddMenuEntry("2",2);
	glutAddMenuEntry("3",3);
	glutAddMenuEntry("4",4);
	glutAddMenuEntry("8",8);
	glutAddMenuEntry("16",16);

	glutCreateMenu(mymenu);//注册菜单回调函数
	glutAddMenuEntry("New Spline",1);//添加菜单项
	glutAddSubMenu("Tools",subMenuTools);
	glutAttachMenu(GLUT_RIGHT_BUTTON);//把当前菜单注册到指定的鼠标键
	glutAddSubMenu("Order",subMenuOrder);
	glutAddMenuEntry("Toggle Polynomial",3);//添加菜单项
	glutAddMenuEntry("Exit",2);//添加菜单项
}

void init(){
	glutInitDisplayMode(GLUT_RGB | GLUT_SINGLE);

	glutInitWindowPosition(winwidth,winheight);
	glutInitWindowSize(winwidth,winheight);
	glutCreateWindow("201900302022 - lab4");

	glClearColor(218/255.0,127/255.0,102/255.0,0);//设置背景色为黑色
	glClear(GL_COLOR_BUFFER_BIT);//将屏幕上的所有像素点置为预置色
	gluOrtho2D(0,winwidth,0,winheight);//变换坐标系到屏幕坐标系
	glMatrixMode(GL_MODELVIEW);
	
	glutMouseFunc(myMouse);
	glutMotionFunc(myMouseMotion);
	initMenu();
	
	glutDisplayFunc(myDisp);
}

int main(int argc,char* argv[]){
	glutInit(&argc,argv);
	init();
	glutMainLoop();
	return 0;
}
