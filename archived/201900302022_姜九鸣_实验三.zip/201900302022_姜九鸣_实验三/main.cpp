#include<cstdio>
#include<iostream>
#include<algorithm>
#include<vector>
#include<cmath>
#include <GL/glut.h>
using namespace std;

const int polygon_num=2;
const int winwidth=600,winheight=600;
const int ssaa=2;//SSAA超采样的倍数
int Ymax;

struct Point{
    int x,y;
};

struct AET{
    double x,dx,ymax;//x:当前Y扫描线与该边的交点x值；dx：增量1/k；ymax：该边较高端点的y值。
    AET* next;
};

struct NET{
    double ymax,xmin,dx;//xmin：较低端点的x值；ymax：较高端点的y值；dx：即1/k，增量。
    NET* next;
};

struct Color{
    GLfloat x,y,z;//rgb
};

vector<Point>Polygon[polygon_num];//第i个多边形的各顶点
vector<Color>PolyColor;//第i个多边形的颜色
vector<double>PolyDepth;//第i个多边形的z值
double zbuffer[winheight+5][winwidth+5],framebuffer[winheight+5][winwidth+5][5];

void XScanning(int index){
    //初始化
    Ymax=0;
    for(int i=0;i<Polygon[index].size();i++)
        Ymax=max(Ymax,Polygon[index][i].y*ssaa);//初始化ymax，ymax是*所有*多边形的最大y值

	//初始化AET，置为空
    AET *A_ET=new AET;
    A_ET->next=NULL;


    //初始化NET，创建空的元素。600*ssaa是为了超采样，把像素总数增多到原来的ssaa倍进行处理，+5是ACM传统（bushi）
    NET *N_ET[600*ssaa+5];//利用y值来标注某处产生的NET元素。因为要超采样，所以采用*ssaa。
    for(int i=0;i<=Ymax;i++){
        N_ET[i]=new NET;
        N_ET[i]->next=NULL;
    }
    double standard=1.0/255;//规一化rgb的值到0-1之间
    
    //建立NET表
    int len=(int)Polygon[index].size();
    for(int i=0;i<len;i++){
        int nxt=(i+1+len)%len;//这个多边形的下一个顶点
        NET *tmp=new NET;//tmp是本次新加入的边
	  
        if(Polygon[index][nxt].y<Polygon[index][i].y){//下降边
            tmp->ymax=Polygon[index][i].y*ssaa;//都需要乘ssaa系数
            tmp->xmin=Polygon[index][nxt].x*ssaa;
            tmp->dx=(double)(Polygon[index][i].x-Polygon[index][nxt].x)/(double)(Polygon[index][i].y-Polygon[index][nxt].y);
            tmp->next=N_ET[Polygon[index][nxt].y*ssaa]->next;
            N_ET[Polygon[index][nxt].y*ssaa]->next=tmp;
        }
        else{//上升边
            tmp->ymax=Polygon[index][nxt].y*ssaa;
            tmp->xmin=Polygon[index][i].x*ssaa;
            tmp->dx=(double)(Polygon[index][i].x-Polygon[index][nxt].x)/(double)(Polygon[index][i].y-Polygon[index][nxt].y);
            tmp->next=N_ET[Polygon[index][i].y*ssaa]->next;
            N_ET[Polygon[index][i].y*ssaa]->next=tmp;
        }
    
    }
    
    
    //建立更新AET
    for(int i=0;i<=Ymax;i++){
        //更新已有的边
        AET* p=A_ET->next;//首元素
        while(p!=NULL){
		  //对x进行增量计算
            p->x=p->x+p->dx;
            p=p->next;
        }
        
        //排序
        p=A_ET->next;//首元素
        AET* current=A_ET;
        current->next=NULL;
        while(p){
            while(current->next&&p->x>=current->next->x)current=current->next;
            AET* tmp=p->next;
            p->next=current->next;
            current->next=p;
            p=tmp;
            current=A_ET;
        }
        
        //删除
        p=A_ET->next;
        current=A_ET;
        while(p){//遍历AET，由于上开下闭，所以如果当前i=ymax，就从AET中删除这个ymax所在的边。
            if(p->ymax==i)
                current->next=p->next;
            else
                current=current->next;
            p=current->next;
        }
        
        //加入新的NET
        NET* np=N_ET[i]->next;//NET在当前y值下的下一个元素
        p=A_ET;
        while(np){
		  //遍历，找出对应的下一个需要加入的AET的边
            while(p->next&&np->xmin>=p->next->x)
                p=p->next;

		//建立新的AET元素
            AET *tmp=new AET;
            tmp->x=np->xmin;
            tmp->ymax=np->ymax;
            tmp->dx=np->dx;
            tmp->next=p->next;
            
            p->next=tmp;
            np=np->next;
            p=A_ET;
        }
        
        //AET点配对，填充颜色
        p=A_ET->next;
        while(p&&p->next){
            for(double j=p->x;j<=p->next->x;j++){
                int xx=(int)(ceil(j/(double)ssaa));//大像素中心x值
                int yy=(int)(ceil((double)i/(double)ssaa));//大像素中心y值
                int x1=(int)(ceil((p->x)/(double)ssaa));//本段开始的大像素中心x值
                int x2=(int)(ceil((p->next->x)/(double)ssaa));//本段结束的大像素中心x值
                if(PolyDepth[index]>zbuffer[xx][yy]){//为了更好的过渡，需要判断边界情况
                    zbuffer[xx][yy]=PolyDepth[index];
                    for(int k=0;k<=2;k++){
                        if(xx==x1||xx==x2)//结束了，就做平均值
					framebuffer[xx][yy][k]/=(ssaa*ssaa);//但是只能减轻后画depth大的情况（小的话，也可以处理，但需要重新修改上层的颜色，较浪费时间）
                        else framebuffer[xx][yy][k]=0;//否则没有结束，那么重置该点颜色值，以便后面进行累加
                    }
			  //做加和，以便反走样的时候做平均值
                    framebuffer[xx][yy][0]+=PolyColor[index].x*standard;
                    framebuffer[xx][yy][1]+=PolyColor[index].y*standard;
                    framebuffer[xx][yy][2]+=PolyColor[index].z*standard;
                }
                else if(PolyDepth[index]==zbuffer[xx][yy]){
                    framebuffer[xx][yy][0]+=PolyColor[index].x*standard;
                    framebuffer[xx][yy][1]+=PolyColor[index].y*standard;
                    framebuffer[xx][yy][2]+=PolyColor[index].z*standard;
                }
            }
            p=p->next->next;//前进**一对**交点
        }
    }
}

void createPoly(){
	Point a1,a2,a3,a4,b1,b2,b3,b4;
	a1.x=350;a1.y=500;
	a2.x=100;a2.y=500;
	a3.x=300;a3.y=100;
	a4.x=450;a4.y=300;
	b1.x=400;b1.y=500;
	b2.x=200;b2.y=100;
	b3.x=400;b3.y=200;
	b4.x=220;b4.y=400;
	Polygon[0].push_back(a1);
	Polygon[0].push_back(a2);
	Polygon[0].push_back(a3);
	Polygon[0].push_back(a4);
	Polygon[1].push_back(b1);
	Polygon[1].push_back(b4);
	Polygon[1].push_back(b2);
	Polygon[1].push_back(b3);
	PolyColor.push_back({164,94,107});
	PolyColor.push_back({136,119,123});
	PolyDepth.push_back(15);
	PolyDepth.push_back(17);
}

void myDisp(){
    glClear(GL_COLOR_BUFFER_BIT);
    //开始绘制多边形
    for(int i=0;i<polygon_num;i++)XScanning(i);
    glBegin(GL_POINTS);
    for(int i=0;i<=winwidth;i++){
        for(int j=0;j<=winheight;j++){
		  //反走样，并渲染出framebuffer
            glColor3f(framebuffer[i][j][0]/(ssaa*ssaa),framebuffer[i][j][1]/(ssaa*ssaa),framebuffer[i][j][2]/(ssaa*ssaa));
            glVertex2i(i,j);
            //cout<<framebuffer[i][j][0]<<" ";
        }
    }
    glEnd();
    glFlush();
}

void init(){
    glClearColor(0,0,0,0);//设置背景色为黑色
    glClear(GL_COLOR_BUFFER_BIT);//将屏幕上的所有像素点置为预置色
    gluOrtho2D(0,winwidth,0,winheight);//变换坐标系到屏幕坐标系
    glMatrixMode(GL_MODELVIEW);
    createPoly();
}

int main(int argc,char* argv[]){
    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_RGB | GLUT_SINGLE);
    glutInitWindowPosition(winwidth,winheight);
    glutInitWindowSize(winwidth,winheight);
    glutCreateWindow("201900302022 - lab3");
    init();
    glutDisplayFunc(myDisp);
    glutMainLoop();
    return 0;
}
